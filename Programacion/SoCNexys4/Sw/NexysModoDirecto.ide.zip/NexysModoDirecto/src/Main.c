#include <math.h>
#include "platform.h"
#include "xbasic_types.h"
#include "xparameters.h"
#include "xstatus.h"
#include "xuartlite.h"
#include "xil_io.h"
#include "xintc.h"
#include "xil_exception.h"



//////////////////////El siguiente C�digo muestra la demo generada para el IP configurado en HW en Modo Directo
//////////////////////



//////////////////////Configuraciones de Interrupciones
	 XIntc  IntcConfig;

////////Definicion de IDs Interrupciones

#define ID_IntSTART 	XPAR_INTC_0_DEVICE_ID
#define ID_IntSTOP 		XPAR_INTC_0_DEVICE_ID + 0x01
#define ID_IntCONFIG	XPAR_INTC_0_DEVICE_ID + 0x02
#define ID_IntVELOCIDAD	XPAR_INTC_0_DEVICE_ID + 0x03

////////Funciones Ligadas a interupciones
void Config_Inicial_Interrupciones(void);
static void ISR_START(void);
static void ISR_STOP(void);
static void ISR_CONFIG(void);
static void ISR_VELOCIDAD(void);
///////////////////////////////////////////
///////////////////////////////////////////
////////Definicion Recepcion Datos por UART

XUartLite UartLite;

#define UARTLITE_DEVICE_ID	XPAR_UARTLITE_0_DEVICE_ID
#define MAXBYTESBUFFER 5
int UART_RECEPCION(int limitebytes);
/////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////

//////////////////////////////////////////Definicion De direcciones del IP Controlador de motores (Sacado de xparameter.h)
#define CUSTOM_IP_BASEADDR 0x44A00000
#define REGISTER_0_OFFSET 0x00
#define REGISTER_1_OFFSET 0x04
#define REGISTER_2_OFFSET 0x08
#define REGISTER_3_OFFSET 0x0C
#define REGISTER_4_OFFSET 0x10
#define REGISTER_5_OFFSET 0x14

/////////////////////////////////Definicion de configuraciones para el IP.
#define START 	0xFFFFFFFF
#define STOP	0x00000000

#define HORARIO 0x00000000
#define ANTIHORARIO 0xFFFFFFFF


///Funciones Escritura y Lectura a direcciones de memoria
int get_custom_ip_register(int baseaddr, int offset);
void set_custom_ip_register(int baseaddr,int offset,int value);

/////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
int DUTY=0;
volatile int FLAG_MENU=0;


///////////////////////////////////////////////////////////////
///////////////////////////////Otras funciones
//Menu
void Menu_OPCIONES();

//////////////////////////////////////////////////////////////


int main()
{
	Config_Inicial_Interrupciones(); //Configurar las interrupciones
	init_platform();
	Menu_OPCIONES();				 // Lanzar el menu de opciones como primera opcion a realizar.
while(1){

	if (FLAG_MENU==1){				//Lanzar el menu tras interrupcion.
		FLAG_MENU=0;
		Menu_OPCIONES();
	}
}
	xil_printf("\r\nFIN");
	cleanup_platform();
	return 0;
}


////////////////////////////////////////////////////////////Funciones lectura escritura AXI
int get_custom_ip_register(int baseaddr, int offset)
{
	unsigned int temp = 0;
	temp = Xil_In32(baseaddr + offset);
	return (temp);
}

void set_custom_ip_register(int baseaddr,int offset,int value)
{
	Xil_Out32(baseaddr+offset,value);
}

///////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////Funcion Recepcion de UART por polling
int UART_RECEPCION(int limitebytes){
	int FLAG=0;
	int valoranterior=0;
	int bytesrecibidos=0;
	u8 variable[limitebytes];
	XIntc_Disable(&IntcConfig, ID_IntSTART);	//Se desactiva el START durante la configuracion
	XIntc_Disable(&IntcConfig, ID_IntCONFIG);	//Se desactiva el Config durante la configuracion
	XIntc_Disable(&IntcConfig, ID_IntVELOCIDAD);
	do{
		int Status;
		Status = XUartLite_Initialize(&UartLite,UARTLITE_DEVICE_ID);
				bytesrecibidos+=XUartLite_Recv(&UartLite,variable+bytesrecibidos,limitebytes-bytesrecibidos);

				if (valoranterior<bytesrecibidos){
						xil_printf("%c",variable[valoranterior]);
				   	   	valoranterior=bytesrecibidos;
				   }

				if (variable[bytesrecibidos-1]==13 && bytesrecibidos>1){
					int SecuenciaOKAY=1;
					//Comprobar que efectivamente los bytes recibidos son n�meros.
					//Controlar que no hay un /n salvo el �ltimo
							for (int i=0; i<bytesrecibidos-1;i++){
								if (variable[i]<48 || variable[i]>57 ){
									xil_printf("\r\nERROR Introduzca unicamente n�meros\n \rIntroduzca: ");
									valoranterior=0;
									bytesrecibidos=0;
									SecuenciaOKAY=0;
									break;
								}
							}
							if (SecuenciaOKAY==1)
									FLAG=1;
				}else if(bytesrecibidos==limitebytes){
					xil_printf("\r\nTama�o excedido Maximo Digitos: %02d ,reintroduzca numero e INTRO al final\n \rIntroduzca: ",limitebytes-1);
					valoranterior=0;
					bytesrecibidos=0;
				}

	}while(FLAG==0);
//Conversion a numero.
	int Valor=0;
	int j=0;
				while(j<bytesrecibidos-1){
					Valor=Valor+((variable[j])-48)*pow(10,bytesrecibidos-2-j);	//Elevar n�mero a la base
					//Valor+((variable[bytesrecibidos-2-j])-48)*
					j++;
				}
	return Valor;
}


/////////////////////////////////////////////////////////////////////////Desarrollo Menu de Configuracion Creado.

void Menu_OPCIONES(){
	int OPCION=0;
	int sentido=0;
	int bytesrecibidos=0;
	int Registro0,Registro1,Registro2=0,Registro3=0,Registro4;
		///Deshabilitar interrupciones posibles salvo la de STOP
		XIntc_Disable(&IntcConfig, ID_IntSTART);
		XIntc_Disable(&IntcConfig, ID_IntCONFIG);
		XIntc_Disable(&IntcConfig, ID_IntVELOCIDAD);

	xil_printf("\n\rControl Motor Modo Directo:\n");
	xil_printf("\rMenu:\n");
	xil_printf("\r1.Duty\n \r2.Sentido\n\r3.Salir\n\r ");
	while(1){
		 OPCION=UART_RECEPCION(2);
			if (OPCION!=1 && OPCION!=2 && OPCION!=3)
				xil_printf("\rIntroduzca opcion 1,2 o 3\n\r");
			else if (OPCION==1){
				xil_printf("\rDuty actual: %03d \n",DUTY);
				xil_printf("\rIntroduzca el duty deseado (0-100): ");
				while(1){

					DUTY=UART_RECEPCION(4);
					if (DUTY<=100)
						break;
					else
						xil_printf("\n\r Duty Incorrecto Reintroduzca Valor (0-100): ");
			}

		Registro2=DUTY*10;
		set_custom_ip_register(CUSTOM_IP_BASEADDR,REGISTER_2_OFFSET,Registro2);
		Registro2=get_custom_ip_register(CUSTOM_IP_BASEADDR,REGISTER_2_OFFSET);

			}else if (OPCION==2){
				xil_printf("\rSentido deseado: 1.Horario y 2.Antihorario");
				do{
					sentido=UART_RECEPCION(2);
					if (sentido!=1 && sentido!=2)
				xil_printf("\rIntroducir opcion 1 o 2:");
				}while(sentido!=1 && sentido!=2);
				if (sentido==1)								//Escrbirir sentido en el registro del IP del sentido de giro
					set_custom_ip_register(CUSTOM_IP_BASEADDR,REGISTER_3_OFFSET,HORARIO);
					else
					set_custom_ip_register(CUSTOM_IP_BASEADDR,REGISTER_3_OFFSET,ANTIHORARIO);
	}else
		break;


			///Definir si seguir en el menu o salir
			xil_printf("\n\r1.Salir Menu 2.Seguir Menu\n\r");
		do{
			OPCION=UART_RECEPCION(2);
			if (OPCION!=1 && OPCION!=2)
				xil_printf("\rIntroducir opcion 1 o 2:");
		}while(OPCION!=1 && OPCION!=2);
			if (OPCION==1)
				break;
			xil_printf("\rMenu:\n");
			xil_printf("\r1.Duty\n \r2.Sentido\n\r3.Salir\n\r ");
	}
	//////////Limpiar los registros de interrupciones y posterioremente volver a habilitarlas.
XIntc_Acknowledge(&IntcConfig, ID_IntSTART);
XIntc_Acknowledge(&IntcConfig, ID_IntCONFIG);
XIntc_Acknowledge(&IntcConfig, ID_IntVELOCIDAD);
XIntc_Enable(&IntcConfig, ID_IntCONFIG);
XIntc_Enable(&IntcConfig, ID_IntSTART);
XIntc_Enable(&IntcConfig, ID_IntVELOCIDAD);
xil_printf("\n\r");

}
//////////////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////////Configuracion Inicial de las Interrupciones
void Config_Inicial_Interrupciones(void){
int status=0;
//////////////////////////////////////////////////Declaracion de Interrupciones
/*
 * 1. Declaracion de funciones de Preconfiguracion de la Interupcion. =XIntc_Initialize
 * 2. Se incorpora el ID sacado de la libreria xparameter.h (conect)
 * 3. Se crea nuestra funcion ISR (Interuption Service Rutine).
 * 4. Se llama a la funcion ISR
 *********Se comunicada nuestro SW con el Handler de interupcion
 * 5. Se conecta el IRQ al procesador. exceptioninit
*/

		   status=XIntc_Initialize(&IntcConfig, ID_IntSTART);
			 if(status!=XST_SUCCESS){
				 xil_printf("Interrupt Initialize failed..");
				 return -1;
			 }

			 status= XIntc_Connect(&IntcConfig, ID_IntSTART,
			 		  (XInterruptHandler)ISR_START , 1);
			 if(status!=XST_SUCCESS){
				 xil_printf("Interrupt Conection failed..");
				 return -1;
			 }

			XIntc_Enable(&IntcConfig,ID_IntSTART);


			Xil_ExceptionInit(); //En Microblaze esto no es tan necesario pero aun asi se ha declarado
			Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,(Xil_ExceptionHandler)XIntc_InterruptHandler,(void *)&IntcConfig);


			status= XIntc_Start(&IntcConfig, XIN_REAL_MODE);
			 if(status!=XST_SUCCESS){
				 xil_printf("Interrupt Start failed..");
				 return -1;
			 }
			 //Interrupt STOP
			 status= XIntc_Connect(&IntcConfig, ID_IntSTOP,
				 		  (XInterruptHandler)ISR_STOP , 0);
				 if(status!=XST_SUCCESS){
					 xil_printf("Interrupt Conection failed..");
					 return -1;
				 }

				XIntc_Enable(&IntcConfig, ID_IntSTOP);


				Xil_ExceptionInit();//En Microblaze esto no es tan necesario.
				Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,(Xil_ExceptionHandler)XIntc_InterruptHandler,(void *)&IntcConfig);

				status= XIntc_Start(&IntcConfig, XIN_REAL_MODE);
				 if(status!=XST_SUCCESS){
					 xil_printf("Interrupt Start failed..");
					 return -1;
				 }

				/*
				 *Fin de Inicializacion de Interupciones
				 */
				 //Interrupt CONFIG
				 status= XIntc_Connect(&IntcConfig, ID_IntCONFIG,
					 		  (XInterruptHandler)ISR_CONFIG , 2);
					 if(status!=XST_SUCCESS){
						 xil_printf("Interrupt Conection failed..");
						 return -1;
					 }

					XIntc_Enable(&IntcConfig, ID_IntCONFIG);


					Xil_ExceptionInit();//En Microblaze esto no es tan necesario.
					Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,(Xil_ExceptionHandler)XIntc_InterruptHandler,(void *)&IntcConfig);

					status= XIntc_Start(&IntcConfig, XIN_REAL_MODE);
					 if(status!=XST_SUCCESS){
						 xil_printf("Interrupt Start failed..");
						 return -1;
					 }
					 //Interrupt Velocidad
					 status= XIntc_Connect(&IntcConfig, ID_IntVELOCIDAD,
						 		  (XInterruptHandler)ISR_VELOCIDAD, 3);
						 if(status!=XST_SUCCESS){
							 xil_printf("Interrupt Conection failed..");
							 return -1;
						 }

						XIntc_Enable(&IntcConfig, ID_IntVELOCIDAD);


						Xil_ExceptionInit();//En Microblaze esto no es tan necesario.
						Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,(Xil_ExceptionHandler)XIntc_InterruptHandler,(void *)&IntcConfig);

						status= XIntc_Start(&IntcConfig, XIN_REAL_MODE);
						 if(status!=XST_SUCCESS){
							 xil_printf("Interrupt Start failed..");
							 return -1;
						 }
		Xil_ExceptionEnable();
}
///////////////////////////////////////////////////////// Funciones ISR
static void ISR_START(){
	/*ISR Estructura general
	 * 1. Se deshabilita la interupcion  para evitar atenderla mientras se esta actualmente gestionando
	 * 2. Escribir mensaje de start
	 * 3. Habilitar interupcion
	 */
	XIntc_Disable(&IntcConfig, ID_IntSTART);
		set_custom_ip_register(CUSTOM_IP_BASEADDR,REGISTER_0_OFFSET,START);
		xil_printf("\n\rSTART\n");
	XIntc_Enable(&IntcConfig, ID_IntSTART);
}

static void ISR_STOP(){
	/*ISR Estructura general
	 * 1. Se deshabilita la interupcion  para evitar atenderla mientras se esta actualmente gestionando
	 * 2. Escribir mensaje de stop
	 * 3. Habilitar interupcion
	 */
	XIntc_Disable(&IntcConfig, ID_IntSTOP);
		set_custom_ip_register(CUSTOM_IP_BASEADDR,REGISTER_0_OFFSET,STOP);
		xil_printf("\n\rSTOP\n");
	XIntc_Enable(&IntcConfig, ID_IntSTOP);
}

static void ISR_CONFIG(){
	/*ISR Estructura general
	 * 1. Se deshabilita la interupcion  para evitar atenderla mientras se esta actualmente gestionando
	 * 2. Adem�s se deshabilita la de velociadad para que no de problemas
	 * 3. Escribir algo mensaje.
	 * 4. Habilitar interupcion
	 */
	XIntc_Disable(&IntcConfig, ID_IntCONFIG);
	XIntc_Disable(&IntcConfig, ID_IntVELOCIDAD);
		FLAG_MENU=1;
	XIntc_Acknowledge(&IntcConfig, ID_IntVELOCIDAD);	//Limpiar registro CONFIG en caso de haber sido interrumpido durante menu
	XIntc_Enable(&IntcConfig, ID_IntCONFIG);
	XIntc_Enable(&IntcConfig, ID_IntVELOCIDAD);


}

static void ISR_VELOCIDAD(){
	/*ISR Estructura general
	 * 1. Se deshabilita la interupcion  para evitar atenderla mientras se esta actualmente gestionando
	 * 2. Calcula la velocidad en RPM y la introduce en el registro de los display del IP
	 * 3. Escribir mensaje de la velocidad en el terminal.
	 * 4. Habilitar interupcion
	 */
	int Velocidad=0;
	int value=0;
	XIntc_Disable(&IntcConfig, ID_IntVELOCIDAD);
	value=get_custom_ip_register(CUSTOM_IP_BASEADDR,REGISTER_4_OFFSET);
	Velocidad=(1/(float)(value*24*0.00000001))*60;
	xil_printf("\rHALL SENSOR RECEIVE:  %04d RPM",Velocidad);
	set_custom_ip_register(CUSTOM_IP_BASEADDR,REGISTER_5_OFFSET,Velocidad);
	XIntc_Acknowledge(&IntcConfig, ID_IntVELOCIDAD);	//Limpiar registro velocidad.
	XIntc_Enable(&IntcConfig, ID_IntVELOCIDAD);
}

